﻿Public Class Form1

    ' Declare constants
    Const decTAX_RATE As Decimal = 0.06D
    Const decWHITE_BAGEL As Decimal = 1.25D
    Const decWHEAT_BAGEL As Decimal = 1.5D
    Const decCREAM_CHEESE As Decimal = 0.5
    Const decBUTTER As Decimal = 0.25D
    Const decBLUEBERRY As Decimal = 0.75D
    Const decRASPBERRY As Decimal = 0.75D
    Const decPEACH As Decimal = 0.75D
    Const decREG_COFFEE As Decimal = 1.25D
    Const decCAPPUCCINO As Decimal = 2D
    Const decDAFE_AU_LAIT As Decimal = 1.75D

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        ' Calculate the total of an order
        Dim decSubtotal As Decimal
        Dim decTax As Decimal
        Dim decTotal As Decimal

        decSubtotal = BagelCost() + ToppingCost() + CoffeeCost()
        decTax = CalcTax(decSubtotal)
        decTotal = decSubtotal + decTax

        txtSubTotal.Text = decSubtotal.ToString("c")
        txtTax.Text = decTax.ToString("c")
        txtTotal.Text = decTotal.ToString("c")
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        ' Reset the controls to default values
        ResetBagels()
        ResetToppings()
        ResetCoffee()
        ResetPrice()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        ' Close  form
        Me.Close()
    End Sub

    Function BagelCost() As Decimal
        ' Return the cost of the selected bagel
        Dim decBagel As Decimal

        If radWhiteBagel.Checked = True Then
            decBagel = decWHITE_BAGEL
        Else
            decBagel = decWHEAT_BAGEL
        End If

        Return decBagel
    End Function

    Function ToppingCost() As Decimal
        ' Return the cost of the toppings.
        Dim decCostOfTopping As Decimal = 0D

        If chkCreamCheese.Checked = True Then
            decCostOfTopping += decCREAM_CHEESE
        End If

        If chkButter.Checked = True Then
            decCostOfTopping += decBUTTER
        End If

        If chkBlueberryJam.Checked = True Then
            decCostOfTopping += decBLUEBERRY
        End If

        If chkRaspberryJam.Checked = True Then
            decCostOfTopping += decRASPBERRY
        End If

        If chkPeachJelly.Checked = True Then
            decCostOfTopping += decPEACH
        End If

        Return decCostOfTopping
    End Function

    Function CoffeeCost() As Decimal
        ' Returns the cost of the selected coffee.
        Dim decCoffee As Decimal

        If radNone.Checked Then
            decCoffee = 0D
        ElseIf radRegularCoffee.Checked = True Then
            decCoffee = decREG_COFFEE
        ElseIf radCappuccino.Checked = True Then
            decCoffee = decCAPPUCCINO
        ElseIf radCafeAuLait.Checked = True Then
            decCoffee = decDAFE_AU_LAIT
        End If

        Return decCoffee
    End Function

    Function CalcTax(ByVal decAmount As Decimal) As Decimal
        ' Calculate Taxes
        Return decAmount * decTAX_RATE
    End Function

    Private Sub ResetBagels()
        ' Resets info
        radWhiteBagel.Checked = True
    End Sub

    Sub ResetToppings()
        ' resets info
        chkCreamCheese.Checked = False
        chkButter.Checked = False
        chkBlueberryJam.Checked = False
        chkRaspberryJam.Checked = False
        chkPeachJelly.Checked = False
    End Sub

    Sub ResetCoffee()
        ' reset info
        radNone.Checked = True
    End Sub

    Sub ResetPrice()
        ' reset price
        lblSubtotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub
End Class

