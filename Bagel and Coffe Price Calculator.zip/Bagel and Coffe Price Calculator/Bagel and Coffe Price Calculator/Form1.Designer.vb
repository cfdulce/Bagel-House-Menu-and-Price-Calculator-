﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        grpToppingsChoice = New GroupBox()
        chkPeachJelly = New CheckBox()
        chkRaspberryJam = New CheckBox()
        chkBlueberryJam = New CheckBox()
        chkButter = New CheckBox()
        chkCreamCheese = New CheckBox()
        grpBagelChoice = New GroupBox()
        radWholeWeatBagel = New RadioButton()
        radWhiteBagel = New RadioButton()
        btnCalculate = New Button()
        btnReset = New Button()
        btnExit = New Button()
        Panel2 = New Panel()
        grpCoffeeChoice = New GroupBox()
        radCafeAuLait = New RadioButton()
        radCappuccino = New RadioButton()
        radRegularCoffee = New RadioButton()
        radNone = New RadioButton()
        Panel3 = New Panel()
        grpOrderPrice = New GroupBox()
        lblTotal = New Label()
        lblTax = New Label()
        lblSubtotal = New Label()
        Label1 = New Label()
        txtSubTotal = New TextBox()
        txtTax = New TextBox()
        txtTotal = New TextBox()
        Panel1.SuspendLayout()
        grpToppingsChoice.SuspendLayout()
        grpBagelChoice.SuspendLayout()
        Panel2.SuspendLayout()
        grpCoffeeChoice.SuspendLayout()
        Panel3.SuspendLayout()
        grpOrderPrice.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Linen
        Panel1.Controls.Add(grpToppingsChoice)
        Panel1.Controls.Add(grpBagelChoice)
        Panel1.Location = New Point(35, 149)
        Panel1.Margin = New Padding(4, 2, 4, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(363, 546)
        Panel1.TabIndex = 0
        ' 
        ' grpToppingsChoice
        ' 
        grpToppingsChoice.Controls.Add(chkPeachJelly)
        grpToppingsChoice.Controls.Add(chkRaspberryJam)
        grpToppingsChoice.Controls.Add(chkBlueberryJam)
        grpToppingsChoice.Controls.Add(chkButter)
        grpToppingsChoice.Controls.Add(chkCreamCheese)
        grpToppingsChoice.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        grpToppingsChoice.Location = New Point(20, 239)
        grpToppingsChoice.Margin = New Padding(4, 2, 4, 2)
        grpToppingsChoice.Name = "grpToppingsChoice"
        grpToppingsChoice.Padding = New Padding(4, 2, 4, 2)
        grpToppingsChoice.Size = New Size(306, 286)
        grpToppingsChoice.TabIndex = 1
        grpToppingsChoice.TabStop = False
        grpToppingsChoice.Text = "Pick Your Toppings"
        ' 
        ' chkPeachJelly
        ' 
        chkPeachJelly.AutoSize = True
        chkPeachJelly.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        chkPeachJelly.Location = New Point(27, 232)
        chkPeachJelly.Margin = New Padding(4, 2, 4, 2)
        chkPeachJelly.Name = "chkPeachJelly"
        chkPeachJelly.Size = New Size(226, 36)
        chkPeachJelly.TabIndex = 4
        chkPeachJelly.Text = "Peach Jelly ($.75)"
        chkPeachJelly.UseVisualStyleBackColor = True
        ' 
        ' chkRaspberryJam
        ' 
        chkRaspberryJam.AutoSize = True
        chkRaspberryJam.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        chkRaspberryJam.Location = New Point(27, 187)
        chkRaspberryJam.Margin = New Padding(4, 2, 4, 2)
        chkRaspberryJam.Name = "chkRaspberryJam"
        chkRaspberryJam.Size = New Size(265, 36)
        chkRaspberryJam.TabIndex = 3
        chkRaspberryJam.Text = "Raspberry Jam ($.75)"
        chkRaspberryJam.UseVisualStyleBackColor = True
        ' 
        ' chkBlueberryJam
        ' 
        chkBlueberryJam.AutoSize = True
        chkBlueberryJam.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        chkBlueberryJam.Location = New Point(27, 142)
        chkBlueberryJam.Margin = New Padding(4, 2, 4, 2)
        chkBlueberryJam.Name = "chkBlueberryJam"
        chkBlueberryJam.Size = New Size(262, 36)
        chkBlueberryJam.TabIndex = 2
        chkBlueberryJam.Text = "Blueberry Jam ($.75)"
        chkBlueberryJam.UseVisualStyleBackColor = True
        ' 
        ' chkButter
        ' 
        chkButter.AutoSize = True
        chkButter.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        chkButter.Location = New Point(27, 95)
        chkButter.Margin = New Padding(4, 2, 4, 2)
        chkButter.Name = "chkButter"
        chkButter.Size = New Size(177, 36)
        chkButter.TabIndex = 1
        chkButter.Text = "Butter ($.25)"
        chkButter.UseVisualStyleBackColor = True
        ' 
        ' chkCreamCheese
        ' 
        chkCreamCheese.AutoSize = True
        chkCreamCheese.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        chkCreamCheese.Location = New Point(27, 48)
        chkCreamCheese.Margin = New Padding(4, 2, 4, 2)
        chkCreamCheese.Name = "chkCreamCheese"
        chkCreamCheese.Size = New Size(266, 36)
        chkCreamCheese.TabIndex = 0
        chkCreamCheese.Text = "Cream Cheese ($.50)"
        chkCreamCheese.UseVisualStyleBackColor = True
        ' 
        ' grpBagelChoice
        ' 
        grpBagelChoice.Controls.Add(radWholeWeatBagel)
        grpBagelChoice.Controls.Add(radWhiteBagel)
        grpBagelChoice.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        grpBagelChoice.Location = New Point(20, 17)
        grpBagelChoice.Margin = New Padding(4, 2, 4, 2)
        grpBagelChoice.Name = "grpBagelChoice"
        grpBagelChoice.Padding = New Padding(4, 2, 4, 2)
        grpBagelChoice.Size = New Size(291, 155)
        grpBagelChoice.TabIndex = 0
        grpBagelChoice.TabStop = False
        grpBagelChoice.Text = "Pick a Bagel"
        ' 
        ' radWholeWeatBagel
        ' 
        radWholeWeatBagel.AutoSize = True
        radWholeWeatBagel.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radWholeWeatBagel.Location = New Point(31, 87)
        radWholeWeatBagel.Margin = New Padding(4, 2, 4, 2)
        radWholeWeatBagel.Name = "radWholeWeatBagel"
        radWholeWeatBagel.Size = New Size(250, 36)
        radWholeWeatBagel.TabIndex = 1
        radWholeWeatBagel.TabStop = True
        radWholeWeatBagel.Text = "Whole Weat ($1.25)"
        radWholeWeatBagel.UseVisualStyleBackColor = True
        ' 
        ' radWhiteBagel
        ' 
        radWhiteBagel.AutoSize = True
        radWhiteBagel.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radWhiteBagel.Location = New Point(31, 39)
        radWhiteBagel.Margin = New Padding(4, 2, 4, 2)
        radWhiteBagel.Name = "radWhiteBagel"
        radWhiteBagel.Size = New Size(183, 36)
        radWhiteBagel.TabIndex = 0
        radWhiteBagel.TabStop = True
        radWhiteBagel.Text = "White ($1.25)"
        radWhiteBagel.UseVisualStyleBackColor = True
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = Color.Linen
        btnCalculate.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnCalculate.Location = New Point(206, 739)
        btnCalculate.Margin = New Padding(4, 2, 4, 2)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(192, 53)
        btnCalculate.TabIndex = 1
        btnCalculate.Text = "Calculate Form"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' btnReset
        ' 
        btnReset.BackColor = Color.Linen
        btnReset.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnReset.Location = New Point(426, 739)
        btnReset.Margin = New Padding(4, 2, 4, 2)
        btnReset.Name = "btnReset"
        btnReset.Size = New Size(177, 53)
        btnReset.TabIndex = 2
        btnReset.Text = "Reset Form"
        btnReset.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Linen
        btnExit.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnExit.Location = New Point(631, 739)
        btnExit.Margin = New Padding(4, 2, 4, 2)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(172, 53)
        btnExit.TabIndex = 3
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.Linen
        Panel2.Controls.Add(grpCoffeeChoice)
        Panel2.Location = New Point(545, 161)
        Panel2.Margin = New Padding(4, 2, 4, 2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(449, 268)
        Panel2.TabIndex = 4
        ' 
        ' grpCoffeeChoice
        ' 
        grpCoffeeChoice.Controls.Add(radCafeAuLait)
        grpCoffeeChoice.Controls.Add(radCappuccino)
        grpCoffeeChoice.Controls.Add(radRegularCoffee)
        grpCoffeeChoice.Controls.Add(radNone)
        grpCoffeeChoice.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        grpCoffeeChoice.Location = New Point(22, 17)
        grpCoffeeChoice.Margin = New Padding(4, 2, 4, 2)
        grpCoffeeChoice.Name = "grpCoffeeChoice"
        grpCoffeeChoice.Padding = New Padding(4, 2, 4, 2)
        grpCoffeeChoice.Size = New Size(401, 223)
        grpCoffeeChoice.TabIndex = 0
        grpCoffeeChoice.TabStop = False
        grpCoffeeChoice.Text = "Want Coffee with that?"
        ' 
        ' radCafeAuLait
        ' 
        radCafeAuLait.AutoSize = True
        radCafeAuLait.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radCafeAuLait.Location = New Point(62, 163)
        radCafeAuLait.Margin = New Padding(4, 2, 4, 2)
        radCafeAuLait.Name = "radCafeAuLait"
        radCafeAuLait.Size = New Size(226, 36)
        radCafeAuLait.TabIndex = 3
        radCafeAuLait.TabStop = True
        radCafeAuLait.Text = "Cafe au lait (1.75)"
        radCafeAuLait.UseVisualStyleBackColor = True
        ' 
        ' radCappuccino
        ' 
        radCappuccino.AutoSize = True
        radCappuccino.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radCappuccino.Location = New Point(62, 119)
        radCappuccino.Margin = New Padding(4, 2, 4, 2)
        radCappuccino.Name = "radCappuccino"
        radCappuccino.Size = New Size(249, 36)
        radCappuccino.TabIndex = 2
        radCappuccino.TabStop = True
        radCappuccino.Text = "Cappuccino ($2.00)"
        radCappuccino.UseVisualStyleBackColor = True
        ' 
        ' radRegularCoffee
        ' 
        radRegularCoffee.AutoSize = True
        radRegularCoffee.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radRegularCoffee.Location = New Point(63, 77)
        radRegularCoffee.Margin = New Padding(4, 2, 4, 2)
        radRegularCoffee.Name = "radRegularCoffee"
        radRegularCoffee.Size = New Size(276, 36)
        radRegularCoffee.TabIndex = 1
        radRegularCoffee.TabStop = True
        radRegularCoffee.Text = "Regular Coffee ($1.25)"
        radRegularCoffee.UseVisualStyleBackColor = True
        ' 
        ' radNone
        ' 
        radNone.AutoSize = True
        radNone.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        radNone.Location = New Point(62, 38)
        radNone.Margin = New Padding(4, 2, 4, 2)
        radNone.Name = "radNone"
        radNone.Size = New Size(104, 36)
        radNone.TabIndex = 0
        radNone.TabStop = True
        radNone.Text = "None"
        radNone.UseVisualStyleBackColor = True
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.Linen
        Panel3.Controls.Add(grpOrderPrice)
        Panel3.Location = New Point(545, 483)
        Panel3.Margin = New Padding(4, 2, 4, 2)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(449, 212)
        Panel3.TabIndex = 5
        ' 
        ' grpOrderPrice
        ' 
        grpOrderPrice.Controls.Add(txtTotal)
        grpOrderPrice.Controls.Add(txtTax)
        grpOrderPrice.Controls.Add(txtSubTotal)
        grpOrderPrice.Controls.Add(lblTotal)
        grpOrderPrice.Controls.Add(lblTax)
        grpOrderPrice.Controls.Add(lblSubtotal)
        grpOrderPrice.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Bold, GraphicsUnit.Point)
        grpOrderPrice.Location = New Point(18, 13)
        grpOrderPrice.Margin = New Padding(4, 2, 4, 2)
        grpOrderPrice.Name = "grpOrderPrice"
        grpOrderPrice.Padding = New Padding(4, 2, 4, 2)
        grpOrderPrice.Size = New Size(405, 178)
        grpOrderPrice.TabIndex = 0
        grpOrderPrice.TabStop = False
        grpOrderPrice.Text = "Order Price"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        lblTotal.Location = New Point(64, 128)
        lblTotal.Margin = New Padding(4, 0, 4, 0)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(65, 32)
        lblTotal.TabIndex = 2
        lblTotal.Text = "Total"
        ' 
        ' lblTax
        ' 
        lblTax.AutoSize = True
        lblTax.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        lblTax.Location = New Point(64, 83)
        lblTax.Margin = New Padding(4, 0, 4, 0)
        lblTax.Name = "lblTax"
        lblTax.Size = New Size(47, 32)
        lblTax.TabIndex = 1
        lblTax.Text = "Tax"
        ' 
        ' lblSubtotal
        ' 
        lblSubtotal.AutoSize = True
        lblSubtotal.Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        lblSubtotal.Location = New Point(64, 38)
        lblSubtotal.Margin = New Padding(4, 0, 4, 0)
        lblSubtotal.Name = "lblSubtotal"
        lblSubtotal.Size = New Size(103, 32)
        lblSubtotal.TabIndex = 0
        lblSubtotal.Text = "Subtotal"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Linen
        Label1.Font = New Font("Segoe UI Black", 18F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(243, 40)
        Label1.Margin = New Padding(4, 0, 4, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(533, 65)
        Label1.TabIndex = 6
        Label1.Text = "Brandi's Bagel House"
        ' 
        ' txtSubTotal
        ' 
        txtSubTotal.BackColor = Color.Bisque
        txtSubTotal.Location = New Point(198, 35)
        txtSubTotal.Name = "txtSubTotal"
        txtSubTotal.ReadOnly = True
        txtSubTotal.Size = New Size(145, 39)
        txtSubTotal.TabIndex = 3
        ' 
        ' txtTax
        ' 
        txtTax.BackColor = Color.Bisque
        txtTax.Location = New Point(198, 83)
        txtTax.Name = "txtTax"
        txtTax.ReadOnly = True
        txtTax.Size = New Size(145, 39)
        txtTax.TabIndex = 4
        ' 
        ' txtTotal
        ' 
        txtTotal.BackColor = Color.Bisque
        txtTotal.Location = New Point(197, 133)
        txtTotal.Name = "txtTotal"
        txtTotal.ReadOnly = True
        txtTotal.Size = New Size(146, 39)
        txtTotal.TabIndex = 5
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.bagelImages
        ClientSize = New Size(1028, 825)
        Controls.Add(Label1)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(btnExit)
        Controls.Add(btnReset)
        Controls.Add(btnCalculate)
        Controls.Add(Panel1)
        Font = New Font("Segoe UI Variable Small Light", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Margin = New Padding(4, 2, 4, 2)
        Name = "Form1"
        Text = "Bagel and Coffee Price Calculator"
        Panel1.ResumeLayout(False)
        grpToppingsChoice.ResumeLayout(False)
        grpToppingsChoice.PerformLayout()
        grpBagelChoice.ResumeLayout(False)
        grpBagelChoice.PerformLayout()
        Panel2.ResumeLayout(False)
        grpCoffeeChoice.ResumeLayout(False)
        grpCoffeeChoice.PerformLayout()
        Panel3.ResumeLayout(False)
        grpOrderPrice.ResumeLayout(False)
        grpOrderPrice.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents grpToppingsChoice As GroupBox
    Friend WithEvents grpBagelChoice As GroupBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents grpCoffeeChoice As GroupBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents grpOrderPrice As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents chkPeachJelly As CheckBox
    Friend WithEvents chkRaspberryJam As CheckBox
    Friend WithEvents chkBlueberryJam As CheckBox
    Friend WithEvents chkButter As CheckBox
    Friend WithEvents chkCreamCheese As CheckBox
    Friend WithEvents radWholeWeatBagel As RadioButton
    Friend WithEvents radWhiteBagel As RadioButton
    Friend WithEvents radRegularCoffee As RadioButton
    Friend WithEvents radNone As RadioButton
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents radCafeAuLait As RadioButton
    Friend WithEvents radCappuccino As RadioButton
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtTax As TextBox
    Friend WithEvents txtSubTotal As TextBox
End Class
